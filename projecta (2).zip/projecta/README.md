# Commit ?

 - napravljene su sve potrebne klase (?)

# To Do

 - napraviti to do

