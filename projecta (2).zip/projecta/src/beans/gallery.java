import java.util.ArrayList;
import Photo;

public class Gallery{

	private ArrayList<Photo> list;

	public Gallery(){
	
	}
	
	public Gallery(ArrayList<Photo> list){
		this.list = list
	}
	
	public ArrayList<Photo> getList(){
		return this.list;
	}
	
	public setList(ArrayList<Photo> list){
		this.list = list;
	}
}
